# Modulare BLE-Anbindung

## Vorhandene Szene

Das Canvas bleibt verdrahtet. `HeartRateBLE` und `CosinussMeasurements` sind jetzt kleine Kompatibilitätskomponenten mit den bisherigen Script-GUIDs. Ihre Implementierung steckt in den allgemeinen Basisklassen `BleConnection` und `SensorMeasurements`. Nicht zusätzlich einen zweiten BLE-Manager auf dasselbe Canvas setzen.

Das voreingestellte Profil liegt unter `Assets/HeartRateBLE/Profiles/Cosinuss.asset`. In der Hierarchy `HeartRateCanvas` auswählen: Im bisherigen HeartRateBLE-Component ist das neue Feld **Profile** zu sehen. Per Klick auf das zugewiesene Asset lassen sich die Einstellungen im Inspector bearbeiten.

## Einstellungen ohne Code ändern

- **Name Contains**: Namens-Teilstrings, z. B. `tree` und `thre`. Leere Liste erlaubt alle Namen, auch namenlose Geräte.
- **Device Id**: Optional exakte Android-Kennung. Standardmäßig leer; keine fest eingetragene Sensoradresse.
- **Channels**: Datenkanäle in gewünschter Reihenfolge. Jeder Kanal hat eine eindeutige ID und einen Anzeigenamen.
- **Service Uuid / Characteristic Uuid**: Vierstellige Standard-UUID oder vollständige 128-Bit-UUID.
- **Format**: HeartRate, Temperature, PulseOximeter, Battery, Text, CosinussStatus oder RawHex.
- **Read / Subscribe**: Einmal lesen und/oder automatische Updates anfordern. Eigenschaften des entdeckten Kanals werden vor dem Auftrag geprüft.
- **Update Mode**: Notify oder Indicate bevorzugen; die native Ergänzung wählt einen tatsächlich unterstützten Modus.
- **Stale Seconds**: Nach dieser Zeit wird ein dynamischer Messwert als veraltet markiert. Geräteinformationen im Textformat bleiben bis zur Trennung sichtbar.

Zum Experimentieren Profil duplizieren (Cmd+D) und die Kopie im Profile-Feld zuweisen. Einstellungen nur im getrennten Zustand ändern; eine Verbindung verwendet eine Kopie der Kanalliste. Für ein ganz neues Profil: Rechtsklick im Project-Fenster → Create → BLE → Geräteprofil. Ein leeres Profil zeigt alle Geräte, abonniert aber noch nichts.

**Beispiel Akkusensor:** Name Contains auf den Namen des neuen Geräts setzen, einen Kanal mit ID `battery`, Service `180f`, Characteristic `2a19`, Format Battery und Read aktivieren. Subscribe nur bei gewünschten Updates aktivieren; der Code prüft die Eigenschaft. Damit wird nicht behauptet, dass jedes Gerät diesen Standardkanal bereitstellt.

Für ein unbekanntes proprietäres Paket zunächst RawHex verwenden. Das zeigt bis zu 64 Bytes als Hex an. Für interpretierte Messwerte braucht es dessen Protokoll und einen passenden Parser. Die große bpm-Anzeige verwendet den ersten HeartRate-Kanal. Weitere konfigurierte Kanäle werden im Detailtext angezeigt; sehr große Profile benötigen eine größere/scrollbare UI.

## Aufteilung

- **BleConnection.cs**: Berechtigungen, Scan, Geräteauswahl, Verbindung, Service-Erkennung und rohe Datenereignisse. Keine Herzfrequenz-/cosinuss-Auswertung.
- **BleDeviceProfile.cs**: Konfiguration, Namens-/Kennungsfilter, UUID-Normalisierung und Validierung.
- **CosinussProfileDefaults.cs**: Ausschließlich das voreingestellte cosinuss-Kanalprofil und die bisherigen Namensfilter.
- **BleGattQueue.cs**: Nacheinander ausgeführte Lese-/Abo-Aufträge mit Timeout. Testbar über `IBleGattBackend` ohne echte Hardware.
- **AndroidBleGattBackend.cs**: Einzige C#-Stelle für Zugriffe auf das bestehende Companion-JAR.
- **SensorMeasurements.cs**: Verbindet Profilkanäle mit Parsern und verwaltet aktuelle Werte. Keine Plugin-Kommandos und keine JNI-Aufrufe.
- **HeartRateParser.cs / CosinussParsers.cs**: Byteformate dekodieren. Unveränderte reine C#-Parser.
- **HeartRateUI.cs**: Oberfläche, generische Verweise auf BleConnection/SensorMeasurements, keine automatische Erstellung einer cosinuss-spezifischen Komponente.
- **Gestures.cs**: Handbedienung, unabhängig von BLE.

Für neue Szenen können direkt BleConnection und SensorMeasurements verwendet werden. Die alten Klassennamen werden nur für bestehende Szenen und Prefabs benötigt. Die UI ist weiterhin eine Messwertoberfläche mit großer Herzfrequenzanzeige; sie ist kein universeller GATT-Explorer.

## Grenzen und Tests

Die native Ergänzung bleibt an Velorexe 0.0.6 / Revision 55d8c12e155cc45bc26cea120d5e8c1e5f231b9f gebunden. Diese Abhängigkeit ist jetzt im Android-Backend isoliert, nicht verschwunden. Das bestehende JAR wurde bei diesem Umbau nicht verändert. Die bekannten Grenzen bei autoConnect-Abbruch und dem DescriptorWrite-Ergebnisstatus bleiben bestehen.

Sensor-Modell und Firmware entscheiden über verfügbare Datenkanäle. Die Auto-Erkennung des alten SpO2-Formats nutzt weiterhin Modelltext `two` und Firmware <=2.0.2. Die Textkanäle dafür müssen die IDs `model` und `firmware` haben. In SensorMeasurements kann Oxygen Format auch ausdrücklich eingestellt werden. Für ein neues proprietäres Format muss ein passender Decoder ergänzt werden; die BLE-Verwaltung bleibt dabei unverändert.

Kein neuer allgemeiner Schreibdialog oder individuelles Abmelden einzelner Abos. Trennen beendet alle Updates dieser Sitzung. Kein bestätigter neuer Hardwaretest.

Die Prüfungen liegen außerhalb von Assets in `BLE-Delivery/Tests`, damit die Test-Doubles nicht im Unity-Build landen. Das Editor-Werkzeug `Tools → Herzfrequenz → Modulares Geräteprofil einrichten` prüft die Referenzen und synthetische Messwertweitergabe. Es startet keinen BLE-Scan. Die Ergebnisdatei heißt `BLE-Delivery/Modular-Ergebnis.txt`.
